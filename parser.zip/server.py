# uvicorn server:app --reload

from fastapi import FastAPI, File, UploadFile, Response, status, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from fastapi.responses import FileResponse
from resparser import ResumeParser
from typing import List
from rank_candidate import sort_candidates
import pandas as pd
import json
import io



app = FastAPI()


# Serve static files
app.mount("/static", StaticFiles(directory="static"), name="static")

# Load templates
templates = Jinja2Templates(directory="templates")

# Define index route
@app.get("/", response_class=HTMLResponse)
async def read_index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.post('/upload/')
async def extract_resume_data(response: Response, files: List[UploadFile] = File()):
    result = []
    for file in files:
        contents = await file.read()
        filename = file.filename
        
        try:
            parser = ResumeParser(io.BytesIO(contents), filename)
            data = parser.get_extracted_data()
        except:
            data = ''
            response.status_code = status.HTTP_206_PARTIAL_CONTENT
        
        result.append(
            {
                'filename': filename,
                'data': data
            }
        )
    resp = {
        'result': result,
    }
    return resp

@app.post('/rank_candidates/')
async def rank_candidates(jd: str, files: List[UploadFile] = File()):
    file_data = []
    for file in files:
        contents = await file.read()
        filename = file.filename

        try:
            parser = ResumeParser(io.BytesIO(contents), filename)
            data = parser.get_extracted_data()

            if data.get('email'):
                file_data.append({'email': data.get('email'), 'Skills': ','.join(data.get('skills'))})
        except:
            continue
        
    df = pd.DataFrame(file_data)
    ranked_df = sort_candidates(jd, df)
    ranked_df.sort_values(by='Score', ascending=False, inplace=True)
    ranked_df['Score'] = ranked_df['Score'] * 100
    
    response = {
        'data': json.loads(ranked_df.to_json(orient='records')),
    }
    return response


