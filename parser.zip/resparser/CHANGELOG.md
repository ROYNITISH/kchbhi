## What will be available in 1.0.6

- Exporting data in JSON
- More robust phone number parsing (earlier it was only for Indian numbers, now internationals are supported as well)
- Custom regex option for parsing phone numbers
- Added banner for CLI
- Address parsing will be available
- .doc parsing bug resolved
- Tests are made available for better code coverage